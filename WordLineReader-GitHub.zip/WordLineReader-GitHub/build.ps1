﻿$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) {
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
}
if (-not (Test-Path -LiteralPath $compiler)) {
    throw 'The .NET Framework C# compiler was not found.'
}
$framework = Split-Path -Parent $compiler
Push-Location -LiteralPath $PSScriptRoot
try {
    New-Item -ItemType Directory -Path 'dist' -Force | Out-Null
    $arguments = @(
        '/nologo', '/target:winexe', '/optimize+', '/out:dist\单行阅读.exe',
        '/reference:System.Windows.Forms.dll', '/reference:System.Drawing.dll', '/reference:System.Xml.dll',
        ('/reference:' + (Join-Path $framework 'WPF\UIAutomationClient.dll')),
        ('/reference:' + (Join-Path $framework 'WPF\UIAutomationTypes.dll')),
        ('/reference:' + (Join-Path $framework 'WPF\WindowsBase.dll')),
        'src\Reader.cs', 'src\Settings.cs'
    )
    & $compiler @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
    Write-Output 'Build completed. See the dist folder.'
}
finally { Pop-Location }

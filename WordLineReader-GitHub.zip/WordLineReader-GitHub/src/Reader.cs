﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Automation;

internal static class Program
{
    [STAThread] static void Main()
    {
        Native.SetProcessDPIAware(); Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        bool created;
        using (var mutex = new Mutex(true, "Local\\WordLineReader_20261106", out created))
        {
            if (!created) { MessageBox.Show("阅读工具已经在运行，请在右下角托盘找到“单行阅读”。", "单行阅读"); return; }
            try { Application.Run(new ReaderContext()); }
            catch (Exception ex) { MessageBox.Show("无法启动：" + ex.Message, "单行阅读"); }
        }
    }
}

internal static class BookLoader
{
    public static string Read(string path, string mode)
    {
        if (new FileInfo(path).Length > 64L * 1024 * 1024) throw new IOException("文件超过 64 MB，请先分卷后再导入。");
        byte[] bytes = File.ReadAllBytes(path);
        string text;
        if (mode != "自动识别")
        {
            Encoding encoding = mode == "GB18030 / GBK" ? Encoding.GetEncoding(54936) :
                mode == "UTF-16 LE" ? (Encoding)new UnicodeEncoding(false, true, true) : new UTF8Encoding(false, true);
            text = encoding.GetString(bytes);
        }
        else if (bytes.Length >= 4 && bytes[0] == 0 && bytes[1] == 0 && bytes[2] == 254 && bytes[3] == 255)
            text = new UTF32Encoding(true, true, true).GetString(bytes);
        else if (bytes.Length >= 4 && bytes[0] == 255 && bytes[1] == 254 && bytes[2] == 0 && bytes[3] == 0)
            text = new UTF32Encoding(false, true, true).GetString(bytes);
        else if (bytes.Length >= 2 && bytes[0] == 255 && bytes[1] == 254)
            text = new UnicodeEncoding(false, true, true).GetString(bytes);
        else if (bytes.Length >= 2 && bytes[0] == 254 && bytes[1] == 255)
            text = new UnicodeEncoding(true, true, true).GetString(bytes);
        else
        {
            try { text = new UTF8Encoding(false, true).GetString(bytes); }
            catch (DecoderFallbackException) { text = Encoding.GetEncoding(54936).GetString(bytes); }
        }
        text = text.TrimStart('\ufeff').Replace("\r\n", "\n").Replace('\r', '\n').Replace("\t", "    ");
        // Blank paragraphs are omitted in the reader; the source TXT is never written.
        var paragraphs = new List<string>();
        foreach (string line in text.Split('\n')) if (!string.IsNullOrWhiteSpace(line)) paragraphs.Add(line.TrimEnd());
        if (paragraphs.Count == 0) throw new IOException("这个文件没有可阅读的文字。");
        return string.Join("\n", paragraphs.ToArray());
    }
}

internal sealed class ReadingSurface : Control
{
    public Action<int> Navigate;
    public Action WidthChanged;
    public string Line = "";
    public int Inset { get { return (int)Math.Round(Width * 0.15); } }
    public int ReadingWidth { get { return Math.Max(20, Width - 2 * Inset); } }
    public const TextFormatFlags Flags = TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;
    public ReadingSurface()
    {
        SetStyle(ControlStyles.Selectable | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
        TabStop = true; BackColor = Color.White; ForeColor = Color.FromArgb(55, 55, 55);
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        TextRenderer.DrawText(e.Graphics, Line, Font, new Rectangle(Inset, 2, ReadingWidth, Height - 2), ForeColor, BackColor, Flags);
    }
    protected override void OnResize(EventArgs e) { base.OnResize(e); if (WidthChanged != null) WidthChanged(); }
    protected override void OnMouseDown(MouseEventArgs e) { Focus(); base.OnMouseDown(e); }
    protected override void OnMouseWheel(MouseEventArgs e) { if (Navigate != null && e.Delta != 0) Navigate(e.Delta < 0 ? 1 : -1); }
}

internal sealed class ReaderBar : Form
{
    public readonly ReadingSurface Surface = new ReadingSurface();
    public Action<int> Navigate;
    public Action Conceal, Import, First, Last, ToggleVisibility;
    public ReaderSettings Options = new ReaderSettings();
    protected override bool ShowWithoutActivation { get { return true; } }
    protected override CreateParams CreateParams { get { var cp = base.CreateParams; cp.ExStyle |= 0x80; return cp; } }
    public ReaderBar()
    {
        Text = "单行阅读"; FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual; AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.White; Font = new Font("宋体", 10.5f);
        Surface.Dock = DockStyle.Fill; Controls.Add(Surface);
        ClientSize = new Size(778, Font.Height + 5);
        Surface.Navigate = delegate(int delta) { if (Navigate != null) Navigate(delta); };
    }
    protected override bool ProcessCmdKey(ref Message msg, Keys key)
    {
        if (key == Options.ToggleKey) { if (ToggleVisibility != null) ToggleVisibility(); return true; }
        if (key == (Keys.Control | Keys.O)) { if (Import != null) Import(); return true; }
        if (key == (Keys.Control | Keys.Home)) { if (First != null) First(); return true; }
        if (key == (Keys.Control | Keys.End)) { if (Last != null) Last(); return true; }
        if (key == Options.NextKey)
        { if (Navigate != null) Navigate(1); return true; }
        if (key == Options.PreviousKey)
        { if (Navigate != null) Navigate(-1); return true; }
        return base.ProcessCmdKey(ref msg, key);
    }
}

// Wrap just the current paragraph, keeping a character offset when the window changes size.
internal sealed class LineLayout
{
    public struct Span { public int Start, Length; public Span(int start, int length) { Start = start; Length = length; } }
    public readonly List<Span> Lines = new List<Span>();
    public int ParagraphStart = -1, ParagraphEnd, Width;
    public void Ensure(string text, int offset, int width, Font font)
    {
        offset = Math.Max(0, Math.Min(offset, text.Length - 1));
        int start = offset == 0 ? 0 : text.LastIndexOf('\n', offset - 1) + 1;
        if (start == ParagraphStart && width == Width) return;
        ParagraphStart = start; Width = width; Lines.Clear();
        int end = text.IndexOf('\n', start); if (end < 0) end = text.Length;
        ParagraphEnd = end;
        string paragraph = text.Substring(start, end - start);
        int[] elements = StringInfo.ParseCombiningCharacters(paragraph);
        int index = 0;
        while (index < elements.Length)
        {
            int lo = index + 1, hi = Math.Min(elements.Length, index + Math.Max(1, width));
            int best = index + 1; // At least one complete text element, even in a very narrow window.
            while (lo <= hi)
            {
                int middle = lo + (hi - lo) / 2;
                int until = middle == elements.Length ? paragraph.Length : elements[middle];
                string candidate = paragraph.Substring(elements[index], until - elements[index]);
                int measured = TextRenderer.MeasureText(candidate, font, new Size(int.MaxValue, int.MaxValue), ReadingSurface.Flags).Width;
                if (measured <= width) { best = middle; lo = middle + 1; } else hi = middle - 1;
            }
            int finish = best == elements.Length ? paragraph.Length : elements[best];
            Lines.Add(new Span(start + elements[index], finish - elements[index]));
            index = best;
        }
    }
    public int Locate(int offset)
    {
        for (int i = Lines.Count - 1; i >= 0; --i) if (Lines[i].Start <= offset) return i;
        return 0;
    }
}

internal sealed class ReaderContext : ApplicationContext
{
    readonly ReaderBar bar = new ReaderBar();
    readonly PaperGeometry geometry = new PaperGeometry();
    readonly LineLayout layout = new LineLayout();
    readonly Form start;
    readonly Label fileLabel, progressLabel, hintLabel;
    readonly ToolStripMenuItem toggleMenu;
    ReaderSettings options;
    readonly ComboBox encodingBox;
    readonly NotifyIcon tray;
    readonly HotkeyWindow hotkey;
    readonly ToolStripMenuItem status;
    readonly System.Windows.Forms.Timer timer;
    readonly string records = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "阅读记录");
    string path, text, mode = "自动识别", markPath;
    long sourceLength, sourceTicks;
    int offset;
    IntPtr word;
    bool enabled, quitting, dirty, warned;
    DateTime lastSaved = DateTime.UtcNow;

    public ReaderContext()
    {
        string settingsError;
        options = ReaderSettings.Load(out settingsError);
        bar.Options = options;
        try { bar.Font = new Font(options.FontName, options.FontSize); }
        catch { options.FontName = "宋体"; options.FontSize = 10.5f; settingsError = "已保存的字体不可用，改用宋体。"; }
        bar.Height = bar.Font.Height + 5;
        start = new Form { Text = "单行阅读 · 导入 TXT", ClientSize = new Size(530, 265), StartPosition = FormStartPosition.CenterScreen,
            FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, Font = new Font("宋体", 10.5f) };
        var hint = hintLabel = new Label { Text = "导入小说 TXT，再打开 Word，点击“开始阅读”。\r\n↑ 上一行；↓ / 空格 下一行；Ctrl + ← 显示 / 收起。\r\n长段落会按显示宽度自动拆行，阅读位置自动记住。", Bounds = new Rectangle(20, 16, 490, 65) };
        encodingBox = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Bounds = new Rectangle(90, 88, 170, 25) };
        encodingBox.Items.AddRange(new object[] { "自动识别", "UTF-8", "GB18030 / GBK", "UTF-16 LE" }); encodingBox.SelectedIndex = 0;
        var encodingLabel = new Label { Text = "编码：", Bounds = new Rectangle(20, 92, 65, 24) };
        fileLabel = new Label { Text = "尚未导入 TXT", AutoEllipsis = true, Bounds = new Rectangle(20, 126, 490, 42) };
        progressLabel = new Label { Bounds = new Rectangle(20, 175, 490, 24) };
        var import = new Button { Text = "导入 TXT", Bounds = new Rectangle(20, 218, 110, 30) };
        var begin = new Button { Text = "开始阅读", Bounds = new Rectangle(145, 218, 110, 30) };
        var customize = new Button { Text = "阅读设置", Bounds = new Rectangle(270, 218, 110, 30) };
        customize.Click += delegate { OpenSettings(); };
        var exit = new Button { Text = "退出工具", Bounds = new Rectangle(395, 218, 110, 30) };
        import.Click += delegate { ImportBook(); };
        begin.Click += delegate { if (text == null) ImportBook(); if (text != null && ShowReading()) start.Hide(); };
        exit.Click += delegate { Quit(); };
        start.Controls.AddRange(new Control[] { hint, encodingLabel, encodingBox, fileLabel, progressLabel, import, begin, customize, exit });
        start.FormClosing += delegate(object sender, FormClosingEventArgs e) { if (!quitting) { e.Cancel = true; start.Hide(); } };
        bar.Navigate = Move; bar.Conceal = Conceal; bar.Import = ImportBook;
        // When registered globally, WM_HOTKEY is the only toggle route.
        // The local route remains available if another app already owns the shortcut.
        bar.ToggleVisibility = delegate { if (hotkey == null || !hotkey.Registered) Toggle(); };
        bar.First = delegate { Jump(0); }; bar.Last = delegate { if (text != null) Jump(text.Length - 1); };
        bar.Surface.WidthChanged = Render;
        bar.FormClosing += delegate(object sender, FormClosingEventArgs e) { if (!quitting) { e.Cancel = true; Conceal(); } };
        var menu = new ContextMenuStrip();
        toggleMenu = (ToolStripMenuItem)menu.Items.Add("显示 / 收起", null, delegate { Toggle(); });
        menu.Items.Add("导入 TXT…", null, delegate { ImportBook(); });
        menu.Items.Add("阅读设置…", null, delegate { OpenSettings(); });
        menu.Items.Add("查看文件 / 导入窗口", null, delegate { Conceal(); start.Show(); start.Activate(); });
        status = new ToolStripMenuItem("尚未导入 TXT") { Enabled = false }; menu.Items.Add(status);
        menu.Items.Add(new ToolStripSeparator()); menu.Items.Add("退出", null, delegate { Quit(); });
        tray = new NotifyIcon { Icon = SystemIcons.Application, Text = "单行阅读", ContextMenuStrip = menu, Visible = true };
        tray.DoubleClick += delegate { Toggle(); };
        hotkey = new HotkeyWindow(Toggle);
        if (!hotkey.TryBind(options.ToggleKey)) tray.ShowBalloonTip(6000, "快捷键被占用", "显示快捷键无法注册，请打开阅读设置更换，或双击托盘图标。", ToolTipIcon.Warning);
        UpdateSettingsText();
        if (settingsError != null) tray.ShowBalloonTip(6000, "已使用默认阅读设置", settingsError, ToolTipIcon.Warning);
        timer = new System.Windows.Forms.Timer { Interval = 120 };
        timer.Tick += delegate { Track(); if (dirty && (DateTime.UtcNow - lastSaved).TotalSeconds >= 1) SavePosition(); };
        timer.Start();
        RestoreLast(); start.Show();
    }
    void UpdateSettingsText()
    {
        string toggleText = KeyNames.Format(options.ToggleKey);
        toggleMenu.Text = "显示 / 收起  " + toggleText + (hotkey.Registered ? "" : "（未注册）");
        tray.Text = "单行阅读";
        hintLabel.Text = "导入小说 TXT，再打开 Word，点击“开始阅读”。\r\n" +
            KeyNames.Format(options.PreviousKey) + " 上一行；" + KeyNames.Format(options.NextKey) + " 下一行。\r\n" +
            "显示 / 收起：" + toggleText + "；可在“阅读设置”中修改。\r\n长段落自动拆行，阅读位置自动记住。";
        hintLabel.Height = 72;
    }
    void OpenSettings()
    {
        bool resume = enabled && bar.Visible;
        Conceal(); hotkey.Suspend();
        try
        {
            using (var dialog = new SettingsDialog(options, ApplySettings))
                dialog.ShowDialog(start.Visible ? start : null);
        }
        finally
        {
            if (!hotkey.Registered && !hotkey.TryBind(options.ToggleKey))
                tray.ShowBalloonTip(6000, "显示快捷键未注册", "快捷键被其他程序占用，请在阅读设置中更换；也可以双击托盘图标。", ToolTipIcon.Warning);
            UpdateSettingsText();
        }
        if (resume && text != null) ShowReading();
    }
    string ApplySettings(ReaderSettings candidate)
    {
        Font fresh;
        try { fresh = new Font(candidate.FontName, candidate.FontSize); }
        catch (Exception ex) { return "无法使用此字体：" + ex.Message; }
        if (!hotkey.TryBind(candidate.ToggleKey))
        { fresh.Dispose(); return "这个显示 / 收起快捷键已被占用或由系统保留，请换一个组合。"; }
        try { candidate.Save(); }
        catch (Exception ex) { hotkey.Suspend(); fresh.Dispose(); return "设置未保存：" + ex.Message; }
        options = candidate; bar.Options = options;
        Font old = bar.Font; layout.ParagraphStart = -1;
        bar.Font = fresh; bar.Height = fresh.Height + 5;
        old.Dispose();
        Render(); if (Native.IsWindow(word)) Place();
        if (text != null) { dirty = true; SavePosition(); }
        UpdateSettingsText();
        return null;
    }
    void RestoreLast()
    {
        try
        {
            string last = Path.Combine(records, "上次阅读.txt");
            if (!File.Exists(last)) return;
            string[] data = File.ReadAllLines(last, Encoding.UTF8);
            if (data.Length >= 1 && File.Exists(data[0])) LoadBook(data[0], data.Length > 1 ? data[1] : "自动识别");
        }
        catch { progressLabel.Text = "上次文件无法打开，请重新导入 TXT。"; }
    }
    void ImportBook()
    {
        bool resume = enabled; enabled = false; bar.Hide(); SavePosition();
        using (var dialog = new OpenFileDialog { Title = "导入小说 TXT", Filter = "TXT 文本文件 (*.txt)|*.txt|所有文件 (*.*)|*.*", CheckFileExists = true, Multiselect = false })
        {
            if (!string.IsNullOrEmpty(path)) dialog.FileName = path;
            if (dialog.ShowDialog(start.Visible ? start : null) == DialogResult.OK)
            {
                try { LoadBook(dialog.FileName, (string)encodingBox.SelectedItem); }
                catch (Exception ex) { MessageBox.Show("导入失败：" + ex.Message, "单行阅读"); }
            }
        }
        if (resume && text != null) ShowReading();
    }
    void LoadBook(string filename, string encodingMode)
    {
        string full = Path.GetFullPath(filename);
        var info = new FileInfo(full); long length = info.Length, ticks = info.LastWriteTimeUtc.Ticks;
        string loaded = BookLoader.Read(full, encodingMode);
        string key;
        using (var sha = SHA256.Create()) key = BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(full.ToUpperInvariant()))).Replace("-", "");
        string bookmark = Path.Combine(records, key + ".txt");
        int restored = 0;
        try
        {
            if (File.Exists(bookmark))
            {
                string[] data = File.ReadAllLines(bookmark, Encoding.UTF8);
                if (data.Length >= 4 && data[0] == length.ToString() && data[1] == ticks.ToString() && data[3] == encodingMode)
                    int.TryParse(data[2], out restored);
            }
        }
        catch { restored = 0; }
        path = full; mode = encodingMode; text = loaded; sourceLength = length; sourceTicks = ticks; markPath = bookmark;
        offset = Math.Max(0, Math.Min(restored, text.Length - 1)); layout.ParagraphStart = -1;
        encodingBox.SelectedItem = mode; fileLabel.Text = path;
        Render(); dirty = true; SavePosition();
    }
    void Render()
    {
        if (text == null) return;
        layout.Ensure(text, offset, bar.Surface.ReadingWidth, bar.Font);
        var span = layout.Lines[layout.Locate(offset)];
        offset = span.Start;
        bar.Surface.Line = text.Substring(span.Start, span.Length); bar.Surface.Invalidate();
        string progress = ((offset + span.Length) * 100.0 / text.Length).ToString("0.0") + "%";
        status.Text = "阅读进度 " + progress; progressLabel.Text = "阅读进度 " + progress + "（自动记忆）";
    }
    void Move(int delta)
    {
        if (text == null) return;
        Render(); int index = layout.Locate(offset);
        if (delta > 0)
        {
            if (index + 1 < layout.Lines.Count) offset = layout.Lines[index + 1].Start;
            else if (layout.ParagraphEnd < text.Length) offset = layout.ParagraphEnd + 1;
            else { status.Text = "已读到末尾"; return; }
        }
        else
        {
            if (index > 0) offset = layout.Lines[index - 1].Start;
            else if (layout.ParagraphStart > 0) offset = layout.ParagraphStart - 2;
            else return;
        }
        Render(); dirty = true;
    }
    void Jump(int position) { if (text == null) return; offset = position; Render(); dirty = true; }
    void SavePosition()
    {
        if (!dirty || text == null) return;
        try
        {
            Directory.CreateDirectory(records);
            AtomicWrite(markPath, sourceLength + "\n" + sourceTicks + "\n" + offset + "\n" + mode);
            AtomicWrite(Path.Combine(records, "上次阅读.txt"), path + "\n" + mode);
            dirty = false; warned = false; lastSaved = DateTime.UtcNow;
        }
        catch (Exception ex)
        {
            lastSaved = DateTime.UtcNow;
            if (!warned) { tray.ShowBalloonTip(6000, "阅读进度尚未保存", ex.Message, ToolTipIcon.Warning); warned = true; }
        }
    }
    static void AtomicWrite(string filename, string content)
    {
        string temp = filename + ".tmp"; File.WriteAllText(temp, content, Encoding.UTF8);
        if (File.Exists(filename)) File.Replace(temp, filename, null); else File.Move(temp, filename);
    }
    void Conceal()
    {
        bool focused = Native.GetForegroundWindow() == bar.Handle;
        enabled = false; bar.Hide(); SavePosition();
        if (focused && Native.IsWindow(word)) Native.SetForegroundWindow(word);
    }
    void Toggle()
    {
        if (enabled && bar.Visible) { Conceal(); return; }
        if (text == null) { start.Show(); start.Activate(); return; }
        if (ShowReading()) start.Hide();
    }
    bool ShowReading()
    {
        IntPtr active = Native.GetForegroundWindow();
        if (Native.IsWord(active)) word = active;
        else if (!Native.IsWindow(word) || !Native.IsWord(word)) word = Native.FindWord();
        if (word == IntPtr.Zero) { MessageBox.Show("请先打开一个 Word 文档，再开始阅读。", "单行阅读"); return false; }
        // Restore only a minimized window; leave maximized and normal windows as they are.
        if (Native.IsIconic(word)) Native.ShowWindow(word, 9);
        Native.SetForegroundWindow(word); enabled = true; Place();
        bar.Show(); Native.SetForegroundWindow(bar.Handle); bar.Activate(); bar.Surface.Focus(); Render();
        return true;
    }
    void Track()
    {
        IntPtr active = Native.GetForegroundWindow();
        if (Native.IsWord(active)) word = active;
        if (!enabled || !Native.IsWindow(word) || Native.IsIconic(word) || (active != word && active != bar.Handle))
        { if (bar.Visible) bar.Hide(); return; }
        Place(); if (!bar.Visible) bar.Show();
        Native.SetWindowPos(bar.Handle, new IntPtr(-1), 0, 0, 0, 0, 0x13);
    }
    void Place()
    {
        Native.RECT rect; if (!Native.GetClientRect(word, out rect)) return;
        Native.POINT origin = new Native.POINT(); Native.ClientToScreen(word, ref origin);
        Rectangle area = Screen.FromHandle(word).WorkingArea;
        geometry.Refresh(word); Rectangle paper = geometry.Get(word);
        int viewportBottom = Math.Min(area.Bottom - 4, origin.Y + rect.Bottom - 32);
        int available = Math.Min(area.Right, origin.X + rect.Right) - Math.Max(area.Left, origin.X);
        int fallbackWidth = Math.Min(794, Math.Max(100, available - 60));
        int left = paper.IsEmpty ? origin.X + (rect.Right - fallbackWidth) / 2 : paper.Left;
        int right = paper.IsEmpty ? left + fallbackWidth : paper.Right;
        left = Math.Max(left, area.Left) + 8; right = Math.Min(right, area.Right) - 8;
        int bottom = paper.IsEmpty ? viewportBottom : Math.Min(viewportBottom, paper.Bottom - 4);
        Rectangle target = new Rectangle(left, Math.Max(area.Top, bottom - bar.Height), Math.Max(100, right - left), bar.Height);
        if (bar.Bounds != target) bar.Bounds = target;
    }
    void Quit()
    {
        SavePosition(); quitting = true; timer.Stop(); timer.Dispose();
        hotkey.Dispose(); tray.Visible = false; tray.Dispose(); bar.Dispose(); start.Dispose(); ExitThread();
    }
}

internal sealed class HotkeyWindow : NativeWindow, IDisposable
{
    readonly Action toggle;
    int activeId;
    public bool Registered { get; private set; }
    public Keys CurrentKey { get; private set; }
    public HotkeyWindow(Action action) { toggle = action; CreateHandle(new CreateParams()); }
    public bool TryBind(Keys key)
    {
        if (Registered && key == CurrentKey) return true;
        int id = activeId == 1 ? 2 : 1;
        uint modifiers = 0x4000;
        if ((key & Keys.Control) != 0) modifiers |= 2;
        if ((key & Keys.Alt) != 0) modifiers |= 1;
        if ((key & Keys.Shift) != 0) modifiers |= 4;
        if (!Native.RegisterHotKey(Handle, id, modifiers, (uint)(key & Keys.KeyCode))) return false;
        if (Registered) Native.UnregisterHotKey(Handle, activeId);
        activeId = id; CurrentKey = key; Registered = true;
        return true;
    }
    public void Suspend() { if (Registered) Native.UnregisterHotKey(Handle, activeId); Registered = false; }
    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x312 && Registered && m.WParam.ToInt32() == activeId) toggle();
        base.WndProc(ref m);
    }
    public void Dispose() { Suspend(); DestroyHandle(); }
}

internal static class Native
{
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int height, uint flags);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder name, int size);
    [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr h, int id, uint modifiers, uint key);
    [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr h, int id);
    public static bool IsWord(IntPtr h)
    {
        if (h == IntPtr.Zero) return false;
        try { var name = new StringBuilder(128); GetClassName(h, name, name.Capacity); if (name.ToString() != "OpusApp") return false; uint pid; GetWindowThreadProcessId(h, out pid); using (var p = Process.GetProcessById((int)pid)) return p.ProcessName.Equals("WINWORD", StringComparison.OrdinalIgnoreCase); }
        catch { return false; }
    }
    public static IntPtr FindWord()
    {
        foreach (Process p in Process.GetProcessesByName("WINWORD"))
        { using (p) { if (p.MainWindowHandle != IntPtr.Zero) return p.MainWindowHandle; } }
        return IntPtr.Zero;
    }
}

// Read visible page geometry only. Never changes the Word document or selection.
internal sealed class PaperGeometry
{
    readonly object sync = new object();
    IntPtr target;
    Rectangle cached;
    bool busy;
    DateTime lastRequest = DateTime.MinValue;
    public Rectangle Get(IntPtr window)
    {
        lock (sync) return target == window ? cached : Rectangle.Empty;
    }
    public void Refresh(IntPtr window)
    {
        lock (sync)
        {
            if (target != window) { target = window; cached = Rectangle.Empty; lastRequest = DateTime.MinValue; }
            if (busy || (DateTime.UtcNow - lastRequest).TotalMilliseconds < 650) return;
            busy = true; lastRequest = DateTime.UtcNow;
        }
        ThreadPool.QueueUserWorkItem(delegate
        {
            Rectangle result = Rectangle.Empty;
            try
            {
                var root = AutomationElement.FromHandle(window);
                var document = root.FindFirst(TreeScope.Descendants,
                    new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Document));
                if (document != null)
                {
                    Rectangle viewport = ConvertRect(document.Current.BoundingRectangle);
                    var pages = document.FindAll(TreeScope.Children, Condition.TrueCondition);
                    long bestArea = 0;
                    foreach (AutomationElement page in pages)
                    {
                        string id = page.Current.AutomationId ?? "";
                        if (id.IndexOf("Word_Page_", StringComparison.OrdinalIgnoreCase) < 0) continue;
                        Rectangle visible = Rectangle.Intersect(viewport, ConvertRect(page.Current.BoundingRectangle));
                        long area = (long)visible.Width * visible.Height;
                        if (visible.Width >= 120 && visible.Height >= 32 && area > bestArea)
                        { result = visible; bestArea = area; }
                    }
                }
            }
            catch { /* Word may be busy, closing, or showing a protected view. */ }
            finally
            {
                lock (sync)
                {
                    if (target == window && !result.IsEmpty) cached = result;
                    busy = false;
                }
            }
        });
    }
    static Rectangle ConvertRect(System.Windows.Rect r)
    {
        if (r.IsEmpty || double.IsInfinity(r.Left) || double.IsInfinity(r.Top) || double.IsNaN(r.Width) || double.IsNaN(r.Height)) return Rectangle.Empty;
        return Rectangle.FromLTRB((int)Math.Ceiling(r.Left), (int)Math.Ceiling(r.Top), (int)Math.Floor(r.Right), (int)Math.Floor(r.Bottom));
    }
}

using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using System.Xml;

internal sealed class ReaderSettings
{
    public Keys ToggleKey = Keys.Control | Keys.Left;
    public Keys PreviousKey = Keys.Up;
    public Keys NextKey = Keys.Down;
    public string FontName = "宋体";
    public float FontSize = 10.5f;
    public static string FilePath { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "阅读设置.xml"); } }
    public string Validate()
    {
        if (!KeyNames.Usable(ToggleKey) || !KeyNames.Usable(PreviousKey) || !KeyNames.Usable(NextKey)) return "请为每一项选择一个按键或组合键。";
        Keys code = ToggleKey & Keys.KeyCode;
        if ((ToggleKey & (Keys.Control | Keys.Alt)) == Keys.None && !(code >= Keys.F1 && code <= Keys.F24))
            return "显示 / 收起快捷键请包含 Ctrl 或 Alt，或者使用 F1～F24 功能键。";
        if (ToggleKey == PreviousKey || ToggleKey == NextKey || PreviousKey == NextKey) return "显示 / 收起、上一行和下一行的按键不能相同。";
        Keys[] reserved = { Keys.Control | Keys.O, Keys.Control | Keys.Home, Keys.Control | Keys.End };
        foreach (Keys key in reserved)
            if (ToggleKey == key || PreviousKey == key || NextKey == key) return "Ctrl+O、Ctrl+Home、Ctrl+End 已用于导入和跳转，请选择其他按键。";
        if (string.IsNullOrWhiteSpace(FontName) || FontSize < 6 || FontSize > 48 || float.IsNaN(FontSize)) return "请选择字体，字号范围为 6～48 磅。";
        return null;
    }
    public static ReaderSettings Load(out string error)
    {
        error = null;
        if (!File.Exists(FilePath)) return new ReaderSettings();
        try
        {
            var xml = new XmlDocument { XmlResolver = null };
            using (var reader = XmlReader.Create(FilePath, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null })) xml.Load(reader);
            XmlElement root = xml.DocumentElement;
            var settings = new ReaderSettings {
                ToggleKey = (Keys)int.Parse(root.GetAttribute("toggle"), CultureInfo.InvariantCulture),
                PreviousKey = (Keys)int.Parse(root.GetAttribute("previous"), CultureInfo.InvariantCulture),
                NextKey = (Keys)int.Parse(root.GetAttribute("next"), CultureInfo.InvariantCulture),
                FontName = root.GetAttribute("font"),
                FontSize = float.Parse(root.GetAttribute("size"), CultureInfo.InvariantCulture)
            };
            string invalid = settings.Validate();
            if (invalid != null) throw new InvalidDataException(invalid);
            return settings;
        }
        catch (Exception ex) { error = ex.Message; return new ReaderSettings(); }
    }
    public void Save()
    {
        var xml = new XmlDocument { XmlResolver = null };
        XmlElement root = xml.CreateElement("ReaderSettings"); xml.AppendChild(root);
        root.SetAttribute("toggle", ((int)ToggleKey).ToString(CultureInfo.InvariantCulture));
        root.SetAttribute("previous", ((int)PreviousKey).ToString(CultureInfo.InvariantCulture));
        root.SetAttribute("next", ((int)NextKey).ToString(CultureInfo.InvariantCulture));
        root.SetAttribute("font", FontName); root.SetAttribute("size", FontSize.ToString(CultureInfo.InvariantCulture));
        string temp = FilePath + ".tmp"; xml.Save(temp);
        if (File.Exists(FilePath)) File.Replace(temp, FilePath, null); else File.Move(temp, FilePath);
    }
}

internal static class KeyNames
{
    public static bool Usable(Keys value)
    {
        Keys code = value & Keys.KeyCode;
        return (value & ~(Keys.KeyCode | Keys.Control | Keys.Alt | Keys.Shift)) == 0 && Enum.IsDefined(typeof(Keys), code) && code != Keys.None &&
            code != Keys.ControlKey && code != Keys.ShiftKey && code != Keys.Menu && code != Keys.LWin && code != Keys.RWin &&
            code != Keys.LControlKey && code != Keys.RControlKey && code != Keys.LShiftKey && code != Keys.RShiftKey &&
            code != Keys.LMenu && code != Keys.RMenu && code != Keys.LButton && code != Keys.RButton &&
            code != Keys.MButton && code != Keys.XButton1 && code != Keys.XButton2;
    }
    public static string Format(Keys value)
    {
        string result = "";
        if ((value & Keys.Control) != 0) result += "Ctrl+";
        if ((value & Keys.Alt) != 0) result += "Alt+";
        if ((value & Keys.Shift) != 0) result += "Shift+";
        Keys code = value & Keys.KeyCode;
        switch (code)
        {
            case Keys.Left: return result + "←";
            case Keys.Right: return result + "→";
            case Keys.Up: return result + "↑";
            case Keys.Down: return result + "↓";
            case Keys.Space: return result + "空格";
            case Keys.Return: return result + "Enter";
            case Keys.Next: return result + "PageDown";
            case Keys.Prior: return result + "PageUp";
            default: return result + code;
        }
    }
}

internal sealed class KeyCaptureBox : TextBox
{
    Keys value;
    public Keys Value { get { return value; } set { this.value = value; Text = KeyNames.Format(value); } }
    public KeyCaptureBox() { ReadOnly = true; BackColor = Color.White; ShortcutsEnabled = false; }
    protected override bool ProcessCmdKey(ref Message msg, Keys key)
    {
        if (KeyNames.Usable(key)) Value = key;
        return true;
    }
}

internal sealed class SettingsDialog : Form
{
    readonly KeyCaptureBox toggle = new KeyCaptureBox(), previous = new KeyCaptureBox(), next = new KeyCaptureBox();
    readonly ComboBox fonts = new ComboBox();
    readonly NumericUpDown size = new NumericUpDown();
    readonly Label preview = new Label();
    Font previewFont;
    public SettingsDialog(ReaderSettings current, Func<ReaderSettings, string> apply)
    {
        Text = "阅读设置"; Font = new Font("宋体", 10.5f); ClientSize = new Size(550, 415);
        StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false;
        var hint = new Label { Text = "点击按键框，直接按下你想用的按键或组合键。\r\n显示 / 收起为全局快捷键；翻页键在阅读条获得焦点时生效。", Bounds = new Rectangle(20, 16, 510, 44) };
        Controls.Add(hint);
        AddRow("显示 / 收起", toggle, 72); AddRow("上一行", previous, 116); AddRow("下一行", next, 160);
        fonts.DropDownStyle = ComboBoxStyle.DropDownList;
        foreach (FontFamily family in FontFamily.Families) { fonts.Items.Add(family.Name); family.Dispose(); }
        fonts.Sorted = true; AddRow("字体", fonts, 204);
        size.Minimum = 6; size.Maximum = 48; size.DecimalPlaces = 1; size.Increment = 0.5m;
        AddRow("字号（磅）", size, 248);
        preview.Bounds = new Rectangle(20, 293, 510, 48); preview.AutoEllipsis = true;
        preview.Text = "预览：月光落在窗前，故事仍在继续。"; preview.BackColor = Color.White; Controls.Add(preview);
        var save = new Button { Text = "保存并应用", Bounds = new Rectangle(20, 365, 135, 32) };
        var defaults = new Button { Text = "恢复默认", Bounds = new Rectangle(205, 365, 130, 32) };
        var cancel = new Button { Text = "取消", Bounds = new Rectangle(390, 365, 130, 32), DialogResult = DialogResult.Cancel };
        Controls.AddRange(new Control[] { save, defaults, cancel });
        defaults.Click += delegate { LoadValues(new ReaderSettings()); };
        save.Click += delegate
        {
            var candidate = new ReaderSettings { ToggleKey = toggle.Value, PreviousKey = previous.Value, NextKey = next.Value,
                FontName = (string)fonts.SelectedItem, FontSize = (float)size.Value };
            string error = candidate.Validate();
            if (error == null) error = apply(candidate);
            if (error != null) { MessageBox.Show(this, error, "设置未保存", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            DialogResult = DialogResult.OK; Close();
        };
        fonts.SelectedIndexChanged += delegate { UpdatePreview(); };
        size.ValueChanged += delegate { UpdatePreview(); };
        LoadValues(current);
    }
    void AddRow(string label, Control control, int y)
    {
        Controls.Add(new Label { Text = label, Bounds = new Rectangle(20, y + 4, 140, 25) });
        control.Bounds = new Rectangle(175, y, 345, 28); Controls.Add(control);
    }
    void LoadValues(ReaderSettings settings)
    {
        toggle.Value = settings.ToggleKey; previous.Value = settings.PreviousKey; next.Value = settings.NextKey;
        string name = settings.FontName;
        if (!fonts.Items.Contains(name)) using (var font = new Font(name, settings.FontSize)) name = font.FontFamily.Name;
        fonts.SelectedItem = name;
        if (fonts.SelectedIndex < 0 && fonts.Items.Count > 0) fonts.SelectedIndex = 0;
        size.Value = (decimal)settings.FontSize; UpdatePreview();
    }
    void UpdatePreview()
    {
        if (fonts.SelectedItem == null) return;
        try
        {
            Font fresh = new Font((string)fonts.SelectedItem, (float)size.Value);
            Font old = previewFont; previewFont = fresh; preview.Font = fresh;
            preview.Text = "预览：月光落在窗前，故事仍在继续。";
            if (old != null) old.Dispose();
        }
        catch { preview.Text = "此字体无法预览，请换一种字体。"; }
    }
    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if (disposing && previewFont != null) { previewFont.Dispose(); previewFont = null; }
    }
}
